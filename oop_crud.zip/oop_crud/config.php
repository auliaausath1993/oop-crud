<?php  
	$config = array('host' => 'localhost',
					'username' => 'root',
					'password' => '',
					'database' => 'oop');

	$db = new mysqli($config['host'],
				     $config['username'],
				     $config['password'],
					 $config['database']);

	if (mysqli_connect_errno()) {
		echo "Database tidak ada";
	}

?>